package abadi.sejahtera.pt.bijb.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import abadi.sejahtera.pt.bijb.R;

public class RegisterActivity extends AppCompatActivity {

    private EditText mNameField,mNumber,mEmailField,mPasswordField,mAlamat,mTanggalLahir1;
    private Button mConfirm;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private String user_id1;
    private String mName,mPhone,mEmail,mPassword,mJalan,mTanggalLahir;
    private TextInputLayout error_nama, error_email2, error_password2, error_hp,error_tanggallahir;
    private ProgressBar pb;
    private int mYear,mMonth,mYear1,mMonth1,mDay1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAlamat = (EditText) findViewById(R.id.alamat);
        mNameField = (EditText) findViewById(R.id.Nama);
        mNumber = (EditText) findViewById(R.id.nomer);
        mEmailField = (EditText) findViewById(R.id.memail);
        mPasswordField = (EditText) findViewById(R.id.mpassword);
        pb = (ProgressBar) findViewById(R.id.pb_reg);
        //error text input layout
        error_nama = (TextInputLayout) findViewById(R.id.error_nama);
        error_email2 = (TextInputLayout) findViewById(R.id.error_email2);
        error_password2 = (TextInputLayout) findViewById(R.id.error_password2);
        error_hp = (TextInputLayout) findViewById(R.id.error_hp);
        error_tanggallahir = (TextInputLayout) findViewById(R.id.eror_tanggallahir);
        mTanggalLahir1 = (EditText) findViewById(R.id.tanggallahir1);
        mTanggalLahir1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear1 = c.get(Calendar.YEAR);
                mMonth1 = c.get(Calendar.MONTH);
                mDay1 = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(RegisterActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                mTanggalLahir1.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, mYear1, mMonth1, mDay1);
                datePickerDialog.show();
            }
        });
        mConfirm = (Button)findViewById(R.id.Confirm);
        mAuth=FirebaseAuth.getInstance();
        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enable();
                mConfirm.setEnabled(true);
                saveUserInformation();
            }
        });

    }
    private void saveUserInformation()
    {
        mName = mNameField.getText().toString();
        mTanggalLahir = mTanggalLahir1.getText().toString();
        mPhone = mNumber.getText().toString();
        mEmail = mEmailField.getText().toString();
        mPassword = mPasswordField.getText().toString();
        mJalan = mAlamat.getText().toString();
        if (check_email(mEmail) && check_name(mName)
                && check_phone(mPhone)
                && check_pass(mPassword))
        {
            mAuth.createUserWithEmailAndPassword
                    (mEmail, mPassword).addOnCompleteListener
                    (RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                user_id1 = mAuth.getCurrentUser().getUid();
                                mDatabase= FirebaseDatabase.getInstance()
                                        .getReference()
                                        .child("Users")
                                        .child("Customer").child(user_id1);
                                Map userInfo = new HashMap();
                                userInfo.put("Name",mName);
                                userInfo.put("Number",mPhone);
                                userInfo.put("Email", mEmail);
                                userInfo.put("Alamat",mJalan);
                                userInfo.put("TanggalLahir",mTanggalLahir);
                                userInfo.put("KodePenumpang",mTanggalLahir+mName);
                                mDatabase.updateChildren(userInfo);
                                disable();
                                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                                startActivity(intent);
                                return;
                            }
                            else { disable();
                                Log.d("RegAc", "Error:"+task.getException());
                                mConfirm.setEnabled(true);
                                try {
                                    throw task.getException();
                                } catch(FirebaseAuthWeakPasswordException e) {
                                    Toast.makeText(RegisterActivity.this,
                                            "Password terlalu lemah", Toast.LENGTH_SHORT).show();
                                } catch(FirebaseAuthInvalidCredentialsException e) {
                                    Toast.makeText(RegisterActivity.this,
                                            "Sign up Eror", Toast.LENGTH_SHORT).show();
                                } catch(FirebaseAuthUserCollisionException e) {
                                    Toast.makeText(RegisterActivity.this,
                                            "User sudah terdaftar", Toast.LENGTH_SHORT).show();
                                } catch(Exception e) {
                                    Toast.makeText(RegisterActivity.this,
                                            "Sign up Eror", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
        } else {
            mConfirm.setEnabled(true);
            disable();
        } }

    private void disable(){
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        pb.setVisibility(View.INVISIBLE);
    }

    private void enable(){
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        pb.setVisibility(View.VISIBLE);
    }
    private boolean check_name(String name){
        int i = name.length();
        if (name.isEmpty()) {
            error_nama.setError("Nama harus terisi");
            return false;
        }
        return true;
    }

    private boolean check_email(String email){
        String regExpn =
                "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                        +"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                        +"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                        +"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(regExpn,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);

        if(matcher.matches()) {
            return true;
        }else{
            error_email2.setError("Email tidak valid");
            //Toast.makeText(RegisterActivity.this, "Email tidak valid!", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean check_phone(String phone){
        if (phone.isEmpty()){
            error_hp.setError("No HP tidak boleh kosong");
            return false;
        }
        return true;
    }

    private boolean check_pass(String pass){
        if (pass.length() < 6 ){
            error_password2.setError("Password harus lebih dari 6 karakter");
            return false;
        }
        return true;
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        System.exit(0);
    }
}
