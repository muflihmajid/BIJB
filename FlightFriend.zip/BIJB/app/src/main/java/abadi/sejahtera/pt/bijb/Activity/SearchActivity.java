package abadi.sejahtera.pt.bijb.Activity;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import abadi.sejahtera.pt.bijb.Model.DataModel;
import abadi.sejahtera.pt.bijb.R;

public class SearchActivity extends AppCompatActivity {

    private EditText mSearchField;
    private ImageButton mSearchBtn;

    private RecyclerView mResultList;

    private DatabaseReference mUserDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mUserDatabase = FirebaseDatabase.getInstance().getReference("Pertanyaan");
        mSearchField = (EditText) findViewById(R.id.search_field);
        mSearchBtn = (ImageButton) findViewById(R.id.search_btn);

        mResultList = (RecyclerView) findViewById(R.id.result_list);
        mResultList.setHasFixedSize(true);
        mResultList.setLayoutManager(new LinearLayoutManager(this));

        mSearchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                firebaseUserSearch(mSearchField.getText().toString());
            }
        });
        mSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String searchText = mSearchField.getText().toString();
                firebaseUserSearch(searchText);

            }
        });

    }
    private void firebaseUserSearch(String searchText) {
        Query firebaseSearchQuery = mUserDatabase.orderByChild("pertanyaan").startAt(searchText).endAt(searchText + "\uf8ff");

        FirebaseRecyclerAdapter<DataModel, UsersViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, UsersViewHolder>(

                DataModel.class,
                R.layout.list_layout,
                UsersViewHolder.class,
                firebaseSearchQuery

        ) {
            @Override
            protected void populateViewHolder(UsersViewHolder viewHolder, DataModel model, int position) {
                viewHolder.setDetails(getApplicationContext(), model.getPertanyaan1(), model.getJawaban1());
            }
        };

        mResultList.setAdapter(firebaseRecyclerAdapter);

    }


    // View Holder Class

    public static class UsersViewHolder extends RecyclerView.ViewHolder {

        View mView;

        public UsersViewHolder(View itemView) {
            super(itemView);

            mView = itemView;

        }

        public void setDetails(Context ctx, String userTanya, String userJawab){

            TextView user_name = (TextView) mView.findViewById(R.id.pertanyaanf);
            TextView user_status = (TextView) mView.findViewById(R.id.jawabanf);
            user_name.setText(userTanya);
            user_status.setText(userJawab);


        }




    }


}
