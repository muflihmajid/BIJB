package abadi.sejahtera.pt.bijb.Activity;


import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import abadi.sejahtera.pt.bijb.R;

public class UbahProfil extends AppCompatActivity {

    private DatabaseReference db;
    private FirebaseUser user;
    private String user_id;
    private ImageView mProfile;
    private EditText alamat;
    private EditText nama_lengkap_edit;
    private EditText email_edit;
    private EditText no_hp_edit;
    private EditText TanggalLahir;
    private Button ganti_edit;
    private int mYear,mMonth,mYear1,mMonth1,mDay1;
    private ImageView edit_nama;
    private ImageView edit_namalengkap;
    private ImageView edit_nohp;
    private ImageView Edit_Tanggal;
    private Uri ResultUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_profil);
        user = FirebaseAuth.getInstance().getCurrentUser();
        user_id = user.getUid();

        mProfile = (ImageView) findViewById(R.id.profileimage1);
        nama_lengkap_edit = (EditText) findViewById(R.id.nama_lengkap_edit);
        alamat  = (EditText) findViewById(R.id.nama_profil_edit);
        email_edit  = (EditText) findViewById(R.id.email_edit);
        TanggalLahir = (EditText) findViewById(R.id.tanggal_lahir);

        no_hp_edit  = (EditText) findViewById(R.id.no_hp_edit);
        edit_nama = (ImageView) findViewById(R.id.edit_profil);
        edit_namalengkap  = (ImageView) findViewById(R.id.edit_namalengkap);
        edit_nohp  = (ImageView) findViewById(R.id.edit_nohp);
        Edit_Tanggal = (ImageView) findViewById(R.id.edit_tanggal_lahir);
        ganti_edit = (Button) findViewById(R.id.ganti_edit);
        email_edit.setFocusable(false);
        TanggalLahir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear1 = c.get(Calendar.YEAR);
                mMonth1 = c.get(Calendar.MONTH);
                mDay1 = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(UbahProfil.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                TanggalLahir.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, mYear1, mMonth1, mDay1);
                datePickerDialog.show();
            }
        });
        mProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,1);
            }
        });


        db= FirebaseDatabase.getInstance().getReference("Users").child("Customer").child(user_id);
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String email = dataSnapshot.child("Email").getValue(String.class);
                String Alamat = dataSnapshot.child("Alamat").getValue(String.class);
                String nama_lengkap = dataSnapshot.child("Name").getValue(String.class);
                String no_hp = dataSnapshot.child("Number").getValue(String.class);
                String ProfilImage = dataSnapshot.child("profileImageUrl").getValue(String.class);
                String TanggalLahir1= dataSnapshot.child("TanggalLahir").getValue(String.class);

                Log.d("Profil", "cek nih: " + user_id);
                TanggalLahir.setText(TanggalLahir1,TextView.BufferType.EDITABLE);
                alamat.setText(Alamat, TextView.BufferType.EDITABLE);
                nama_lengkap_edit.setText(nama_lengkap, TextView.BufferType.EDITABLE);
                email_edit.setText(email, TextView.BufferType.EDITABLE);
                no_hp_edit.setText(no_hp, TextView.BufferType.EDITABLE);
                if(ProfilImage!=null)
                {
                    Glide.with(UbahProfil.this).load(ProfilImage).into(mProfile);
                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        ganti_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db =  FirebaseDatabase.getInstance().getReference("Users").child("Customer").child(user_id);
                db.child("Name").setValue(nama_lengkap_edit.getText().toString());
                db.child("Alamat").setValue(alamat.getText().toString());
                db.child("Number").setValue(no_hp_edit.getText().toString());
                db.child("TanggalLahir").setValue(TanggalLahir.getText().toString());
                if(ResultUri != null)
                {
                    StorageReference filePath = FirebaseStorage.getInstance().getReference().child("profile_images").child(user_id);
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(getApplication().getContentResolver(),ResultUri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG,20,baos);
                    byte[] data = baos.toByteArray();
                    UploadTask uploadTask = filePath.putBytes(data);

                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            finish();
                            return;
                        }
                    });
                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Uri downloadUri = taskSnapshot.getDownloadUrl();
                            Map newImage = new HashMap();
                            Log.d("Ubah", "Uri: " + downloadUri);
                            newImage.put("profileImageUrl",downloadUri.toString());
                            db.updateChildren(newImage);
                            finish();
                            return;
                        }
                    });
                }

                Toast.makeText(UbahProfil.this, "Update Berhasil", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(UbahProfil.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == Activity.RESULT_OK)
        {
            final Uri imageUri = data.getData();
            ResultUri = imageUri;
            mProfile.setImageURI(ResultUri);
        }
    }

}
