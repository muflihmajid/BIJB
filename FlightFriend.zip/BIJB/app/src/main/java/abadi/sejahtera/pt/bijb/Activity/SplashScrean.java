package abadi.sejahtera.pt.bijb.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import abadi.sejahtera.pt.bijb.R;


public class SplashScrean extends AppCompatActivity {

    private ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screan);
        iv = (ImageView) findViewById(R.id.Logo);
        Animation myAnim = AnimationUtils.loadAnimation(this,R.anim.mytrans);
        iv.startAnimation(myAnim);
        final Intent intent = new Intent(this,LoginActivity.class);
        Thread timer = new Thread ()
        {
            public void run ()
            {
                try {
                    sleep(2000);
                }catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    startActivity(intent);
                    finish();
                }
            }
        };
        timer.start();
    }
}
