package abadi.sejahtera.pt.bijb.Activity;

import abadi.sejahtera.pt.bijb.Remote.IGoogleService;
import abadi.sejahtera.pt.bijb.Remote.RetrofitClient;
import retrofit2.Retrofit;

public class Common {
    private static final String GOOGLE_API_URL = "https://maps.googleapis.com/maps/";
    public static IGoogleService getGoogleAPIService()
    {
        return RetrofitClient.getClient(GOOGLE_API_URL).create(IGoogleService.class);
    }
}
