package abadi.sejahtera.pt.bijb.Fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

import abadi.sejahtera.pt.bijb.Activity.LoginActivity;
import abadi.sejahtera.pt.bijb.Activity.MainActivity;
import abadi.sejahtera.pt.bijb.Activity.SearchActivity;
import abadi.sejahtera.pt.bijb.Activity.UbahProfil;
import abadi.sejahtera.pt.bijb.R;

public class ProfilFragment extends Fragment {
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    private DatabaseReference mGuideDatabase;
    private ImageView imageView;
    private TextView name,btnSettings;
    private String mName,profile;
    private View btncs,btnhistory;
    private CardView btnLogOut,FAQ;
    private String user_id1;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_profil, container, false);
        ((MainActivity) getActivity())
                .setActionBarTitle("Akun Saya");
        imageView = (ImageView) view.findViewById(R.id.user_photo);
        name = (TextView) view.findViewById(R.id.displayed_name);
        btnLogOut = view.findViewById(R.id.logout);
        FAQ = view.findViewById(R.id.FAQ);
        btnSettings = view.findViewById(R.id.edit);
        auth = FirebaseAuth.getInstance();
        user_id1=auth.getCurrentUser().getUid();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mGuideDatabase= FirebaseDatabase.getInstance().getReference().child("Users").child("Customer").child(user_id1);
        getUserInfo();
        //
        FAQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),SearchActivity.class);
                startActivity(intent);
            }
        });
        //        setDataToView(user);
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(getActivity(),UbahProfil.class);
                startActivity(intent);
            }
        });
        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                Intent intent = new Intent(getActivity(),LoginActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }
    private void getUserInfo()
    {
        mGuideDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0)
                {
                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                    if(map.get("Name")!=null)
                    {
                        mName = map.get("Name").toString();
                        name.setText(mName);
                    }
                    if(map.get("profileImageUrl")!=null)
                    {
                        profile =map.get("profileImageUrl").toString();
                        Glide.with(getActivity()).load(profile).apply(RequestOptions.circleCropTransform()).into(imageView);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public interface OnFragmentInteractionListener {
    }
}
