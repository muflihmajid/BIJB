package abadi.sejahtera.pt.bijb.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import abadi.sejahtera.pt.bijb.R;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
    }
}
