package abadi.sejahtera.pt.bijb.Activity;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.location.LocationListener;

import abadi.sejahtera.pt.bijb.Fragment.DestinasiFragment;
import abadi.sejahtera.pt.bijb.Fragment.HomeFragment;
import abadi.sejahtera.pt.bijb.Fragment.ProfilFragment;
import abadi.sejahtera.pt.bijb.Model.DataModel;
import abadi.sejahtera.pt.bijb.R;

public class MainActivity extends AppCompatActivity implements HomeFragment.OnFragmentInteractionListener,DestinasiFragment.OnFragmentInteractionListener,ProfilFragment.OnFragmentInteractionListener,LocationListener {



    private AHBottomNavigation bottomNavigation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AHBottomNavigationItem item1 =
                new AHBottomNavigationItem("Home",
                        R.drawable.ic_home_white_24dp);
        AHBottomNavigationItem item2 =
                new AHBottomNavigationItem("Destinasi",
                        R.drawable.ic_location_on_black_24dp);
        AHBottomNavigationItem item3 =
                new AHBottomNavigationItem("Profil",
                        R.drawable.ic_person_black_24dp);
        bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        // Set background color
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));
        // Change colors
        bottomNavigation.setAccentColor(Color.parseColor("#00BCD4"));
        bottomNavigation.setInactiveColor(Color.parseColor("#000000"));
        bottomNavigation.setCurrentItem(1);
        Fragment fragment;
        fragment = new HomeFragment();
        loadFragment(fragment);
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.setBehaviorTranslationEnabled(true);
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                Fragment fragment;
                switch (position){
                    case 0:
                        fragment = new HomeFragment();
                        loadFragment(fragment);
                        return true;
                    case 1:
                        fragment = new DestinasiFragment();
                        loadFragment(fragment);
                        return true;
                    case 2:
                        fragment = new ProfilFragment();
                        loadFragment(fragment);

                        return true;

                }
                return true;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    @Override
    public void onFragmentInteraction(Uri uri) {

    }
    public void setActionBarTitle(String title) {
        getSupportActionBar().setTitle(title);
    }
    public void setActionBarTitle1(String title, int icon) {
        getSupportActionBar().setTitle(title);
        getSupportActionBar().setLogo(icon);
        getSupportActionBar().setIcon(icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
    }
    @Override
    public void onLocationChanged(Location location) {
        DataModel model1 = new DataModel();
        model1.setLongitude1(location.getLongitude());
        model1.setLatitude1(location.getLatitude());
    }
    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keycode, event);
    }
}
