package abadi.sejahtera.pt.bijb.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import abadi.sejahtera.pt.bijb.R;

public class TipsActivity extends AppCompatActivity {

    private ScaleGestureDetector mScaleGestureDetector;

    private float mScaleFactor = 1.0f;
    public String mDeskripsi,mGambar;
    public TextView penjelasan;
    public ImageView tampilan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);
        try {
            Intent intent = getIntent();
            mGambar = intent.getStringExtra("gambar");
            mDeskripsi = intent.getStringExtra("deskripsi").replace("_b", System.getProperty("line.separator"));
        } catch(Exception e) {
            e.printStackTrace();
        }
        tampilan = (ImageView) findViewById(R.id.tampilan);
        penjelasan = (TextView) findViewById(R.id.penjelasan);
        Picasso.with(TipsActivity.this)
                .load(mGambar)
                .transform(new RoundedTransformation(15, 0))
                .placeholder(R.drawable.logo)   // optional
                .error(R.drawable.ic_android_black_24dp)      // optional
                .fit()
                .centerInside()
                .into(tampilan);
        penjelasan.setText(mDeskripsi);
    }
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {

        mScaleGestureDetector.onTouchEvent(motionEvent);

        return true;

    }
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {

        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector){

            mScaleFactor *= scaleGestureDetector.getScaleFactor();

            mScaleFactor = Math.max(0.1f,

                    Math.min(mScaleFactor, 10.0f));

            tampilan.setScaleX(mScaleFactor);

            tampilan.setScaleY(mScaleFactor);

            return true;

        }
    }
}
