package abadi.sejahtera.pt.bijb.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.NinePatchDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import abadi.sejahtera.pt.bijb.Activity.DetailActivity;
import abadi.sejahtera.pt.bijb.Activity.MainActivity;
import abadi.sejahtera.pt.bijb.Activity.RoundedTransformation;
import abadi.sejahtera.pt.bijb.Activity.TambahPenerbangan;
import abadi.sejahtera.pt.bijb.Activity.TipsActivity;
import abadi.sejahtera.pt.bijb.Model.DataModel;
import abadi.sejahtera.pt.bijb.Model.Function;
import abadi.sejahtera.pt.bijb.Model.LinePagerIndicatorDecoration;
import abadi.sejahtera.pt.bijb.R;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link HomeFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    String OPEN_WEATHER_MAP_API = "55b93a58960009204a8fc648d10491d3";
    private RecyclerView mResultList,mResultList1;
    public RelativeLayout backgroundhitam;
    private OnFragmentInteractionListener mListener;
    private TextView mMaskapai,mKodepesawat,mTujuan,mJam,mGate,Mremark,mLanding;
    private String maskapait,kodet,mtuju,mj,mgt,mr,mkodepenumpang,mkodepenumpang2,mJamlanding,mlg;
    private DatabaseReference db,mTourismDatabase,mDb,mdb1;
    private FirebaseAuth mAuth;
    private String user_id1;
    private ImageView LogoPesawat;
    private VideoView videobaru;
    TextView currentTemperatureField,weatherIcon;
    ProgressBar loader;
    Typeface    weatherFont;
    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        ((MainActivity) getActivity())
                .setActionBarTitle1("Flight Friend",R.drawable.logo);
        mAuth= FirebaseAuth.getInstance();
        user_id1 = mAuth.getCurrentUser().getUid();
        //background pesawat
        backgroundhitam =(RelativeLayout) v.findViewById(R.id.Black);
        backgroundhitam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),TambahPenerbangan.class);
                startActivity(intent);
            }
        });
        //inisialisasipesawat
        mLanding = (TextView) v.findViewById(R.id.landing);
        mMaskapai = (TextView) v.findViewById(R.id.Maskapaitrb);
        mKodepesawat = (TextView) v.findViewById(R.id.Kodepesawat);
        mTujuan = (TextView) v.findViewById(R.id.Tujuan);
        mJam = (TextView) v.findViewById(R.id.Jam);
        mGate = (TextView) v.findViewById(R.id.Gate);
        Mremark = (TextView) v.findViewById(R.id.Remark);
        LogoPesawat = (ImageView) v.findViewById(R.id.logopesawat1);

        //video
        videobaru = (VideoView) v.findViewById(R.id.video);
        //Destinasi
        mResultList = (RecyclerView) v.findViewById(R.id.result_list4);
        //Tips
        mResultList1 = (RecyclerView) v.findViewById(R.id.result_list8);
        //Cuaca
        weatherIcon = (TextView) v.findViewById(R.id.weather_icon);
        currentTemperatureField = (TextView) v.findViewById(R.id.current_temperature_field);
        weatherFont = Typeface.createFromAsset(getContext().getAssets(), "fonts/weathericons-regular-webfont.ttf");
        weatherIcon.setTypeface(weatherFont);
        taskLoadUp("Majalengka");
        Penerbangan();
        Destinasi();
        Tips();
        video();
        return v;
    }

    private void video()
    {
        String str = "https://firebasestorage.googleapis.com/v0/b/bijb-11e04.appspot.com/o/Video%2FMy%20Movie.mp4?alt=media&token=1a6901dd-e848-4f4a-80a2-3c2618fbe131";
        Uri uri = Uri.parse(str);

        videobaru.setVideoURI(uri);
        videobaru.setVisibility(View.VISIBLE);
        videobaru.requestFocus();
        videobaru.start();
    }
    private void Tips()
    {
        Query firebaseSearchQuery = FirebaseDatabase.getInstance().getReference("Tips");
        final FirebaseRecyclerAdapter firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, UsersViewHolder3>(
                DataModel.class,
                R.layout.pager_tips,
                UsersViewHolder3.class,
                firebaseSearchQuery
        ) {
            @Override
            protected void populateViewHolder(UsersViewHolder3 viewHolder, DataModel model, int position) {
                viewHolder.setDetails(model.getGambar1());
            }
            @Override
            public void onBindViewHolder(final UsersViewHolder3 viewHolder, final int position) {
                final DataModel model1 = getItem(position);
                populateViewHolder(viewHolder, model1, position);
                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getActivity(),TipsActivity.class);
                        intent.putExtra("gambar",model1.getGambar1());
                        intent.putExtra("deskripsi",model1.getDeskripsi1());
                        startActivity(intent);
                    }
                });
            }

        };

        mResultList1.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false));
//        mResultList.addItemDecoration(new LinePagerIndicatorDecoration());
        mResultList1.setAdapter(firebaseRecyclerAdapter);
    }
    private void Destinasi()
    {
        Query firebaseSearchQuery = FirebaseDatabase.getInstance().getReference("Destinasi");
        final FirebaseRecyclerAdapter firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, UsersViewHolder>(
                DataModel.class,
                R.layout.pager_item,
                UsersViewHolder.class,
                firebaseSearchQuery
        ) {
            @Override
            protected void populateViewHolder(UsersViewHolder viewHolder, DataModel model, int position) {
                Log.d("tes", "key folder: " + model.getImage1());
                viewHolder.setDetails(model.getDestinasi1(), model.getImage1());
            }
            @Override
            public void onBindViewHolder(final UsersViewHolder viewHolder, final int position) {
                final DataModel model1 = getItem(position);
                populateViewHolder(viewHolder, model1, position);
                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getActivity(),DetailActivity.class);
                        intent.putExtra("nama",model1.getDestinasi1());
                        intent.putExtra("latitude",model1.getLatitude2());
                        intent.putExtra("longitude",model1.getLongitude2());
                        intent.putExtra("deskripsi",model1.getDeskripsi1());
                        Log.d("tes", "key folderHome: " + model1.getLatitude2());
                        startActivity(intent);
                    }
                });
            }

        };

        mResultList.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false));
//        mResultList.addItemDecoration(new LinePagerIndicatorDecoration());
        mResultList.setAdapter(firebaseRecyclerAdapter);

    }
    private void Penerbangan() {
        db = FirebaseDatabase.getInstance().getReference().child("Users").child("Customer").child(user_id1);
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0)
                {
                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                    if(map.get("KodePenumpang")!=null)
                    {
                        mkodepenumpang = map.get("KodePenumpang").toString();
                        mDb = FirebaseDatabase.getInstance().getReference().child("Penerbangan");
                        mDb.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for(DataSnapshot postSnapshot : dataSnapshot.getChildren())
                                {
                                    for(DataSnapshot postSnapshot1 : postSnapshot.getChildren())
                                    {
                                        for( DataSnapshot postSnapshot2 : postSnapshot1.getChildren())
                                        {
                                            for(DataSnapshot postSnapshot3 : postSnapshot2.getChildren())
                                            {
                                                for(DataSnapshot postSnapshot4 : postSnapshot3.getChildren())
                                                {
                                                    String folder = postSnapshot4.child("Kode").getValue(String.class);
                                                    if(folder.equals(mkodepenumpang))
                                                    {
                                                        maskapait = postSnapshot2.child("Maskapai").getValue(String.class);
                                                        kodet = postSnapshot2.child("Kode").getValue(String.class);
                                                        mJamlanding = postSnapshot2.child("Landing").getValue(String.class);
                                                        mtuju = postSnapshot2.child("Tujuan").getValue(String.class);
                                                        mj = postSnapshot2.child("Time").getValue(String.class);
                                                        mgt = postSnapshot2.child("Gate").getValue(String.class);
                                                        mr = postSnapshot2.child("Remark").getValue(String.class);
                                                        mlg = postSnapshot2.child("logo").getValue(String.class);
                                                        Log.d( "LOGO NICH: ",mlg);
                                                        String tanggal = postSnapshot2.child("Tanggal").getValue(String.class);
                                                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                                                        Date strDate = null;
                                                        try {
                                                            strDate = sdf.parse(tanggal);
                                                        } catch (Throwable e) {
                                                            e.printStackTrace();
                                                        }
                                                        if (System.currentTimeMillis()-(Integer.parseInt("43200")*1000)> (strDate.getTime()))
                                                        {
                                                            mMaskapai.setText("-");
                                                            mKodepesawat.setText("-");
                                                            mTujuan.setText("-");
                                                            mJam.setText("-");
                                                            mGate.setText("-");
                                                            Mremark.setText("-");
                                                            mLanding.setText("-");
                                                            backgroundhitam.setVisibility(View.VISIBLE);
                                                            backgroundhitam.setClickable(true);
                                                        }
                                                        else
                                                        {
                                                            Picasso.with(getContext())
                                                                    .load(mlg)
                                                                    .placeholder(R.drawable.logo)   // optional
                                                                    .error(R.drawable.ic_android_black_24dp)      // optional
                                                                    .into(LogoPesawat);
                                                            mMaskapai.setText(maskapait);
                                                            mKodepesawat.setText(kodet);
                                                            mTujuan.setText(mtuju);
                                                            mJam.setText(mj);
                                                            mLanding.setText(mJamlanding);
                                                            mGate.setText(mgt);
                                                            Mremark.setText(mr);
                                                            Log.d("tes", "key folder: " + folder);
                                                            Log.d("tes", "key folder: " + mkodepenumpang);
                                                            backgroundhitam.setVisibility(View.INVISIBLE);
                                                            backgroundhitam.setClickable(false);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        backgroundhitam.setVisibility(View.VISIBLE);
                                                        backgroundhitam.setClickable(true);
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    public void taskLoadUp(String query) {
        if (Function.isNetworkAvailable(getContext().getApplicationContext())) {
            DownloadWeather task = new DownloadWeather();
            task.execute(query);
        } else {
            Toast.makeText(getContext().getApplicationContext(), "No Internet Connection", Toast.LENGTH_LONG).show();
        }
    }
    class DownloadWeather extends AsyncTask< String, Void, String > {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        protected String doInBackground(String...args) {
            String xml = Function.excuteGet("http://api.openweathermap.org/data/2.5/weather?q=" + args[0] +
                    "&units=metric&appid=" + OPEN_WEATHER_MAP_API);
            return xml;
        }
        @Override
        protected void onPostExecute(String xml) {

            try {
                JSONObject json = new JSONObject(xml);
                if (json != null) {
                    JSONObject details = json.getJSONArray("weather").getJSONObject(0);
                    JSONObject main = json.getJSONObject("main");
                    DateFormat df = DateFormat.getDateTimeInstance();
                    currentTemperatureField.setText(String.format("%.2f", main.getDouble("temp")) + "°");

                    Log.d("tes", "key folder1: " + String.format("%.2f", main.getDouble("temp")) + "°");
                    weatherIcon.setText(Html.fromHtml(Function.setWeatherIcon(details.getInt("id"),
                            json.getJSONObject("sys").getLong("sunrise") * 1000,
                            json.getJSONObject("sys").getLong("sunset") * 1000)));

                }
            } catch (JSONException e) {
                Toast.makeText(getContext().getApplicationContext(), "Error, Check City", Toast.LENGTH_SHORT).show();
            }


        }



    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    public static class UsersViewHolder3 extends RecyclerView.ViewHolder {
        View mView;
        public static final int MULTI_SELECTION = 2;
        public static final int SINGLE_SELECTION = 1;
        AdapterView.OnItemSelectedListener itemSelectedListener;


        public UsersViewHolder3(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setDetails(String image) {
            ImageView foto = (ImageView) mView.findViewById(R.id.img_pager_tips);

            Picasso.with(mView.getContext())
                    .load(image)
                    .transform(new RoundedTransformation(15, 0))
                    .placeholder(R.drawable.logo)   // optional
                    .error(R.drawable.ic_android_black_24dp)      // optional
                    .fit()
                    .centerInside()
                    .into(foto);
        }

    }
    public static class UsersViewHolder extends RecyclerView.ViewHolder {
        View mView;
        public static final int MULTI_SELECTION = 2;
        public static final int SINGLE_SELECTION = 1;
        AdapterView.OnItemSelectedListener itemSelectedListener;


        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setDetails(String destinasi, String image) {
            ImageView foto = (ImageView) mView.findViewById(R.id.img_pager_item);
            TextView nama = (TextView) mView.findViewById(R.id.NamaDestinasi);

            Picasso.with(mView.getContext())
                    .load(image)
                    .transform(new RoundedTransformation(15, 0))
                    .placeholder(R.drawable.logo)   // optional
                    .error(R.drawable.ic_android_black_24dp)      // optional
                    .fit()
                    .centerInside()
                    .into(foto);
            nama.setText(destinasi);
        }

    }
}
