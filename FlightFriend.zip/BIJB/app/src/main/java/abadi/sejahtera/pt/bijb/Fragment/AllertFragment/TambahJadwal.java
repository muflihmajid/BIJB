package abadi.sejahtera.pt.bijb.Fragment.AllertFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import abadi.sejahtera.pt.bijb.Activity.MainActivity;

public class TambahJadwal extends DialogFragment
{
    //settergetter
    public String Tanggal;
    public String Destinasi;
    public String Maskapai;
    public String KodePenerbangan;
    public String Image;
    //data

    private String member;
    private int jml;
    private FirebaseAuth mAuth;
    private String user_id1;
    private DatabaseReference db,mTourismDatabase,mDb,mdb1;
    private String Kodepenumpang;

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getTanggaltrb() {
        return Tanggal;
    }

    public void setTanggaltrb(String tanggal1) {
        Tanggal = tanggal1;
    }

    public String getDestinasitrb() {
        return Destinasi;
    }

    public void setDestinasitrb(String destinasi1) {
        Destinasi = destinasi1;
    }

    public String getMaskapaitrb() {
        return Maskapai;
    }

    public void setMaskapaitrb(String maskapai1) {
        Maskapai = maskapai1;
    }

    public String getKodePenerbanganbr() {
        return KodePenerbangan;
    }

    public void setKodePenerbanganbr(String kodePenerbangan1) {
        KodePenerbangan = kodePenerbangan1;
    }
    public Dialog onCreateDialog (Bundle savedInstanceState)
    {
        mAuth= FirebaseAuth.getInstance();
        user_id1 = mAuth.getCurrentUser().getUid();
        return new AlertDialog.Builder(getActivity())
                .setTitle("Penambahan penerbangan")
                // Set Dialog Message
                .setMessage("Apakah anda akan menambahkan jadawal penerbangan ini?")

                // Positive button
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        db = FirebaseDatabase.getInstance().getReference().child("Users").child("Customer").child(user_id1);
                        db.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0)
                                {
                                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                                    if(map.get("KodePenumpang")!=null)
                                    {
                                        Kodepenumpang = map.get("KodePenumpang").toString();
                                        mDb = FirebaseDatabase.getInstance().getReference().child("Penerbangan").child(Tanggal).child(Maskapai).child(Destinasi).child("Penumpang");
                                        mDb.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                for(DataSnapshot postSnapshot2: dataSnapshot.getChildren())
                                                {
                                                    member=postSnapshot2.getKey();
                                                    jml=Integer.valueOf(member)+1;
                                                }
                                                if(member==null)
                                                {
                                                    jml=1;
                                                }
                                                mdb1=FirebaseDatabase.getInstance().getReference().child("Penerbangan").child(Tanggal).child(Maskapai).child(Destinasi).child("Penumpang").child(String.valueOf(jml));
                                                Map penumpang = new HashMap();
                                                penumpang.put("Kode",Kodepenumpang);
                                                mdb1.updateChildren(penumpang);
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        mTourismDatabase= FirebaseDatabase.getInstance().getReference().child("Users").child("Customer").child(user_id1).child("Riwayat").child(Tanggal).child(Maskapai).child(Destinasi);
                           Map Members = new HashMap();
                           Members.put("Tanggal",Tanggal);
                           Members.put("Destinasi",Destinasi);
                           Members.put("Maskapai",Maskapai);
                           Members.put("KodePenerbangan",KodePenerbangan);
                           Members.put("logo",Image);
                           mTourismDatabase.updateChildren(Members);
                           Intent intent = new Intent(getActivity(),MainActivity.class);
                           startActivity(intent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,	int which) {
                        // Do something else
                    }
                }).create();
    }
}
