package abadi.sejahtera.pt.bijb.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import abadi.sejahtera.pt.bijb.Fragment.HomeFragment;
import abadi.sejahtera.pt.bijb.Model.DataModel;
import abadi.sejahtera.pt.bijb.Model.LinePagerIndicatorDecoration;
import abadi.sejahtera.pt.bijb.R;
import abadi.sejahtera.pt.bijb.Remote.IGoogleService;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

public class DetailActivity extends AppCompatActivity {
    public String folder,nama,mlatitudes,mlongitudes,mDeskripsi,destinasitujuan,mFasilitas;
    private LocationManager locationManager;
    private String provider;
    private ImageView arrowarr,arrowarr1;
    private CardView arr,arr2,arr3;
    private net.cachapa.expandablelayout.ExpandableLayout expandable_Deskripsi,expandable_Fasilitasds;
    private DatabaseReference mDb,mDb1;
    private boolean fabExpanded = false;
    private RecyclerView mResultList,mResultList1;
    private TextView MJudul,MDeskripsi1;

    IGoogleService mService;
    double latitude,longitude,latitudedes,longitudedes;
    private static final int MY_PERMISSION_CODE = 10000;
    private Location mLastLocation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        try {

            Intent intent = getIntent();
            nama = intent.getStringExtra("nama");
            mDeskripsi = intent.getStringExtra("deskripsi").replace("_b", System.getProperty("line.separator"));
            mlatitudes= intent.getStringExtra("latitude");
            mlongitudes = intent.getStringExtra("longitude");
            latitudedes = Double.parseDouble(mlatitudes);
            longitudedes = Double.parseDouble(mlongitudes);
        } catch(Exception e) {
            e.printStackTrace();
        }
        arr3 = (CardView) findViewById(R.id.loc);
        expandable_Deskripsi = (net.cachapa.expandablelayout.ExpandableLayout) findViewById(R.id.expandable_des);
        expandable_Fasilitasds = (net.cachapa.expandablelayout.ExpandableLayout) findViewById(R.id.expandable_fas);
        mResultList = (RecyclerView) findViewById(R.id.result_list5);
        //fasilitas
        mResultList1 = (RecyclerView) findViewById(R.id.result_fasilitas);
        arr = (CardView) findViewById(R.id.desk);
        arr2 = (CardView) findViewById(R.id.fasilitas);
        MJudul = (TextView) findViewById(R.id.judul);
        MDeskripsi1 = (TextView) findViewById(R.id.deskripsi);
        arrowarr = (ImageView) findViewById(R.id.arrow);
        arrowarr1 = (ImageView) findViewById(R.id.arrow1);
        //lastlocation
        mylocation();
        checkfirebase();
        checkfasilitas();
        MJudul.setText(nama);
        MDeskripsi1.setText(mDeskripsi);
        arr3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent navigation = new Intent(Intent.ACTION_VIEW, Uri
                        .parse("http://maps.google.com/maps?saddr="
                                + latitude + ","
                                + longitude + "&daddr="
                                + latitudedes + "," + longitudedes));
                navigation.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                startActivity(navigation);
            }
        });
        arr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandable_Deskripsi.toggle();
                if(fabExpanded==false)
                {
                    arrowarr.setImageResource(R.drawable.ic_arrow_drop_up_color_24dp);
                    fabExpanded=true;
                }
                else
                {
                    arrowarr.setImageResource(R.drawable.ic_arrow_drop_down_color_24dp);
                    fabExpanded=false;
                }
            }
        });

        arr2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandable_Fasilitasds.toggle();
                if(fabExpanded==false)
                {
                    arrowarr1.setImageResource(R.drawable.ic_arrow_drop_up_color_24dp);
                    fabExpanded=true;
                }
                else
                {
                    arrowarr1.setImageResource(R.drawable.ic_arrow_drop_down_color_24dp);
                    fabExpanded=false;
                }
            }
        });

    }
    private void checkfasilitas() {
        mDb1 = FirebaseDatabase.getInstance().getReference().child("Destinasi");
        mDb1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren())
                {
                    mFasilitas = postSnapshot.child("Destinasi").getValue(String.class);
                    if(nama.equals(mFasilitas))
                    {
                        adapterfasilitas(mFasilitas);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void adapterfasilitas(String mFasilitas1) {
        Query firebaseSearchQuery = FirebaseDatabase.getInstance().getReference("Fasilitas").child(mFasilitas1);
        final FirebaseRecyclerAdapter firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, DetailActivity.UsersViewHolder1>(
                DataModel.class,
                R.layout.pager_fasilitas,
                DetailActivity.UsersViewHolder1.class,
                firebaseSearchQuery
        ) {
            @Override
            protected void populateViewHolder(DetailActivity.UsersViewHolder1 viewHolder, DataModel model, int position) {
                viewHolder.setDetails1(model.getFasilitas1());
            }
            @Override
            public void onBindViewHolder(final DetailActivity.UsersViewHolder1 viewHolder, final int position) {
                final DataModel model1 = getItem(position);
                populateViewHolder(viewHolder, model1, position);
            }

        };
        mResultList1.setLayoutManager(new GridLayoutManager(DetailActivity.this,2));
        mResultList1.setAdapter(firebaseRecyclerAdapter);
    }

    public static class UsersViewHolder1 extends RecyclerView.ViewHolder {
        View mView;
        public static final int MULTI_SELECTION = 2;
        public static final int SINGLE_SELECTION = 1;
        AdapterView.OnItemSelectedListener itemSelectedListener;


        public UsersViewHolder1(View itemView) {
            super(itemView);
            mView = itemView;

        }

        public void setDetails1(String fasilitasdestinasi) {
            ImageView foto = (ImageView) mView.findViewById(R.id.logo);
            TextView nama = (TextView) mView.findViewById(R.id.namafasilitas);

            if(fasilitasdestinasi.equals("Parkir"))
            {
                foto.setImageResource(R.drawable.parking);
            }
            if(fasilitasdestinasi.equals("Outbond"))
            {
                foto.setImageResource(R.drawable.outbond);
            }
            if(fasilitasdestinasi.equals("Mushola"))
            {
                foto.setImageResource(R.drawable.mushola);
            }
            if(fasilitasdestinasi.equals("Toilet"))
            {
                foto.setImageResource(R.drawable.toilet);
            }
            if(fasilitasdestinasi.equals("Persewaan"))
            {
                foto.setImageResource(R.drawable.persewaan);
            }
            if(fasilitasdestinasi.equals("Penginapan"))
            {
                foto.setImageResource(R.drawable.penginapan);
            }
            if(fasilitasdestinasi.equals("Tidak ada fasilitas umum"))
            {
                foto.setImageResource(R.drawable.none);
            }
            nama.setText(fasilitasdestinasi);
        }

    }
    private void checkfirebase() {
        mDb = FirebaseDatabase.getInstance().getReference().child("Destinasi");
        mDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren())
                {
                    destinasitujuan = postSnapshot.child("Destinasi").getValue(String.class);
                    if(nama.equals(destinasitujuan))
                    {
                        adapterdestinasi(destinasitujuan);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void adapterdestinasi(String folderdes)
    {
        Query firebaseSearchQuery = FirebaseDatabase.getInstance().getReference("Gambar").child(folderdes);
        final FirebaseRecyclerAdapter firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, DetailActivity.UsersViewHolder>(
                DataModel.class,
                R.layout.pemandangan,
                DetailActivity.UsersViewHolder.class,
                firebaseSearchQuery
        ) {
            @Override
            protected void populateViewHolder(DetailActivity.UsersViewHolder viewHolder, DataModel model, int position) {
                Log.d("tes", "key folder: " + model.getImage1());
                viewHolder.setDetails(model.getGambar1());
            }
            @Override
            public void onBindViewHolder(final DetailActivity.UsersViewHolder viewHolder, final int position) {
                final DataModel model1 = getItem(position);
                populateViewHolder(viewHolder, model1, position);
            }

        };

        mResultList.setLayoutManager(new LinearLayoutManager(DetailActivity.this,LinearLayoutManager.HORIZONTAL,false));
        mResultList.addItemDecoration(new LinePagerIndicatorDecoration());
        mResultList.setAdapter(firebaseRecyclerAdapter);


    }
    public static class UsersViewHolder extends RecyclerView.ViewHolder {
        View mView;
        public static final int MULTI_SELECTION = 2;
        public static final int SINGLE_SELECTION = 1;
        AdapterView.OnItemSelectedListener itemSelectedListener;


        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setDetails(String image) {
            ImageView foto = (ImageView) mView.findViewById(R.id.tampilandes);

            Picasso.with(mView.getContext())
                    .load(image)
                    .placeholder(R.drawable.logo)   // optional
                    .error(R.drawable.ic_android_black_24dp)      // optional
                    .fit()
                    .centerInside()
                    .into(foto);
        }

    }
    private void mylocation() {
        //lastlocation
        mService = Common.getGoogleAPIService();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            checkLocationPermission();
        }
        locationManager = (LocationManager) DetailActivity.this.getSystemService(Context.LOCATION_SERVICE);

        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        criteria.setAltitudeRequired(false);
        criteria.setSpeedRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(false);

        provider = locationManager.getBestProvider(criteria, false);

        if (ActivityCompat.checkSelfPermission(DetailActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(DetailActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(provider);
        if (location != null)
        {
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            Log.d("tes", "folder posisiku: " + latitude);
            Log.d("tes", "folder posisiku: " + longitude);
        }
        else
            Log.i("Log info", "No location");

    }

    private boolean checkLocationPermission() {
        if(ContextCompat.checkSelfPermission(DetailActivity.this,android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            if(ActivityCompat.shouldShowRequestPermissionRationale(DetailActivity.this,android.Manifest.permission.ACCESS_FINE_LOCATION))
            {
                ActivityCompat.requestPermissions(DetailActivity.this,new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                },MY_PERMISSION_CODE);
            }
            else
            {
                ActivityCompat.requestPermissions(DetailActivity.this,new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                },MY_PERMISSION_CODE);
            }
            return false;
        }
        return true;
    }
}
