package abadi.sejahtera.pt.bijb.Model;

public class DataModel {
    //dipakai daftarjarak
    public Double dlongitude;
    public Double dlatitude;

    //Penerbangan
    public String Landing;
    public String Gate;
    public String Time;
    public String Maskapai;
    public String Tujuan;
    public String Remark;
    public String logo;
    public String Kode;
    public String Tanggal;

    //Pertanyaan
    public String pertanyaan;
    public String jawaban;

    //Destinasi
    public String Gambar;
    public String Image;
    public String Destinasi;
    public String Longitude;
    public String Latitude;
    public String Deskripsi;
    public String Fasilitas;
    //
    public String getLanding1() {
        return Landing;
    }

    public void setLanding1(String landing2) {
        Landing = landing2;
    }
    public String getFasilitas1() {
        return Fasilitas;
    }

    public void setFasilitas1(String fasilitas2) {
        Fasilitas = fasilitas2;
    }


    public String getGambar1() {
        return Gambar;
    }

    public void setGambar1(String gambar1) {
        Gambar = gambar1;
    }

    public String getDeskripsi1() {
        return Deskripsi;
    }

    public void setDeskripsi1(String deskripsi2) {
        Deskripsi = deskripsi2;
    }


    public String getLongitude2() {
        return Longitude;
    }

    public void setLongitude2(String longitude3) {
        Longitude = longitude3;
    }

    public String getLatitude2() {
        return Latitude;
    }

    public void setLatitude2(String latitude3) {
        Latitude = latitude3;
    }

    public String getPertanyaan1() {
        return pertanyaan;
    }

    public void setPertanyaan1(String pertanyaan2) {
        this.pertanyaan = pertanyaan2;
    }

    public String getJawaban1() {
        return jawaban;
    }

    public void setJawaban1(String jawaban2) {
        this.jawaban = jawaban2;
    }
    public String getImage1() {
        return Image;
    }

    public void setImage1(String image1) {
        Image = image1;
    }

    public String getDestinasi1() {
        return Destinasi;
    }

    public void setDestinasi1(String destinasi1) {
        Destinasi = destinasi1;
    }


    public String getTanggaltrb() {
        return Tanggal;
    }

    public void setTanggaltrb(String tanggal1) {
        Tanggal = tanggal1;
    }

    public String getKodetrb() {
        return Kode;
    }

    public void setKodetrb(String kode) {
        Kode = kode;
    }

    public String getTujuanTerbang() {
        return Tujuan;
    }

    public void setTujuanTerbang(String tujuantrb) {
        Tujuan = tujuantrb;
    }


    public String getJamTerbang() {
        return Time;
    }

    public void setJamTerbang(String jamtrb) {
        Time = jamtrb;
    }


    public String getMaskapaipenerbangan() {
        return Maskapai;
    }

    public void setMaskapaipenerbangan(String maskapaiterbang) {
        Maskapai = maskapaiterbang;
    }


    public String getRemarkterbang() {
        return Remark;
    }

    public void setRemarkterbang(String remark) {
        Remark = remark;
    }

    public DataModel(String Remark1, String Gate1, String Logo)
    {
        this.Remark=Remark1;
        this.Gate=Gate1;
        this.logo=Logo;
    }

    public String getlogo1() {
        return logo;
    }

    public void setlogo1(String logo12) {
        this.logo = logo12;
    }

    public String getgatebaru() {
        return Gate;
    }

    public void setgatebaru(String gate) {
        Gate = gate;
    }
    public DataModel(){}
    public String nama;
    public Double getlongitude1() {
        return dlongitude;
    }
    public void setLongitude1(Double longitude1) {
        this.dlongitude = longitude1;
    }
    public Double getLatitude1() {
        return dlatitude;
    }
    public void setLatitude1(Double latitude1) {
        this.dlatitude = latitude1;
    }
}
