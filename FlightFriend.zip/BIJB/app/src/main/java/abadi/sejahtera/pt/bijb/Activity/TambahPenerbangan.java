package abadi.sejahtera.pt.bijb.Activity;

import android.app.DatePickerDialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import abadi.sejahtera.pt.bijb.Fragment.AllertFragment.TambahJadwal;
import abadi.sejahtera.pt.bijb.Model.DataModel;
import abadi.sejahtera.pt.bijb.R;

public class TambahPenerbangan extends AppCompatActivity {

    private EditText mtanggal;
    private String tanggal,maskapai;
    private RecyclerView mResultList;
    private FirebaseUser user;
    private Spinner Maskapai;
    private ImageButton searching;
    private DatabaseReference mUserDatabase,mDatabase;
    private int mYear,mMonth,mYear1,mMonth1,mDay1;
    FragmentManager manager = getFragmentManager();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_penerbangan);
        mUserDatabase = FirebaseDatabase.getInstance().getReference("Penerbangan");
        mUserDatabase.keepSynced(true);
        user = FirebaseAuth.getInstance().getCurrentUser();
        mtanggal = (EditText) findViewById(R.id.TanggalTerbang);
        mtanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear1 = c.get(Calendar.YEAR);
                mMonth1 = c.get(Calendar.MONTH);
                mDay1 = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(TambahPenerbangan.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                mtanggal.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, mYear1, mMonth1, mDay1);
                datePickerDialog.show();
            }
        });
        Maskapai = (Spinner) findViewById(R.id.maskapai);
        Maskapai.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, final View view, int position, long id) {

                maskapai=Maskapai.getSelectedItem().toString();
                tanggal=mtanggal.getText().toString();
                Query firebaseSearchQuery = FirebaseDatabase.getInstance().getReference("Penerbangan").child(tanggal).child(maskapai);
                final FirebaseRecyclerAdapter firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<DataModel, TambahPenerbangan.UsersViewHolder>(
                        DataModel.class,
                        R.layout.cardview,
                        TambahPenerbangan.UsersViewHolder.class,
                        firebaseSearchQuery
                ) {
                    @Override
                    protected void populateViewHolder(UsersViewHolder viewHolder, DataModel model, int position) {
                        viewHolder.setDetails(model.getMaskapaipenerbangan(),model.getTujuanTerbang(),model.getJamTerbang(),model.getlogo1());
                    }

                    @Override
                    public void onBindViewHolder(final UsersViewHolder viewHolder, final int position) {
                        final DataModel model1 = getItem(position);
                        populateViewHolder(viewHolder, model1, position);
                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                TambahJadwal tambahJadwal = new TambahJadwal();
                                tambahJadwal.setTanggaltrb(model1.getTanggaltrb());
                                tambahJadwal.setDestinasitrb(model1.getTujuanTerbang());
                                tambahJadwal.setMaskapaitrb(model1.getMaskapaipenerbangan());
                                tambahJadwal.setKodePenerbanganbr(model1.getKodetrb());
                                tambahJadwal.setImage(model1.getlogo1());
                                tambahJadwal.show(manager,"");
                            }
                        });
                    }
                };
                mResultList.setLayoutManager(new GridLayoutManager(TambahPenerbangan.this,2));
                mResultList.setAdapter(firebaseRecyclerAdapter);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mResultList = (RecyclerView) findViewById(R.id.result_list1);
        searching = (ImageButton) findViewById(R.id.search);
        searching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Maskapai.setVisibility(View.VISIBLE);
                tanggal=mtanggal.getText().toString();
                mDatabase = FirebaseDatabase.getInstance().getReference("Penerbangan").child(tanggal);
                mDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        final List<String> maskapai = new ArrayList<String>();
                        for (DataSnapshot areaSnapshot: dataSnapshot.getChildren()) {
                            String destinasi1 = areaSnapshot.getKey();
                            maskapai.add(destinasi1);
                        }
                        Spinner areaSpinner = (Spinner) findViewById(R.id.maskapai);
                        ArrayAdapter<String> areasAdapter = new ArrayAdapter<String>(TambahPenerbangan.this, android.R.layout.simple_spinner_item, maskapai);
                        areasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        areaSpinner.setAdapter(areasAdapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });

    }
    public static class UsersViewHolder extends RecyclerView.ViewHolder {
        View mView;
        public static final int MULTI_SELECTION = 2;
        public static final int SINGLE_SELECTION = 1;
        AdapterView.OnItemSelectedListener itemSelectedListener;


        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }

        public void setDetails(String Maskapai, String Tujuan,String Jam,String logo) {
            TextView namamaskapai = (TextView) mView.findViewById(R.id.Nama_maskapai);
            TextView tujuan = (TextView) mView.findViewById(R.id.TujuanT);
            TextView jam = (TextView) mView.findViewById(R.id.Jam);
            ImageView Logo = (ImageView) mView.findViewById(R.id.logo);
            namamaskapai.setText(Maskapai);
            tujuan.setText(Tujuan);
            jam.setText(Jam);
            Glide.with(mView).load(logo).into(Logo);
            Log.d("tes", "key jam: " + Jam);
        }
    }
}
