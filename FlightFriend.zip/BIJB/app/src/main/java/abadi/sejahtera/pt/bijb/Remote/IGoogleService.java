package abadi.sejahtera.pt.bijb.Remote;

import abadi.sejahtera.pt.bijb.Model.MyPlaces;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface IGoogleService {
    @GET
    Call<MyPlaces> getNearByPlace(@Url String url);
}
